const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('bot latency'),
    async execute(interaction) {
        await interaction.deferReply();
        const ping = Date.now() - interaction.createdTimestamp;

        const msg = ping > 200
            ? `this hoster is fucking shit (${ping}ms)`
            : `wonderful hoster (${ping}ms)`;

        await interaction.editReply(msg);
    }
};
