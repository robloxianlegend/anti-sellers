const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const fs = require('fs');
const path = require('path');
const configPath = path.join(__dirname, '../config/freaks.json');

function loadConfig() {
    if (!fs.existsSync(configPath)) fs.writeFileSync(configPath, '{}');
    return JSON.parse(fs.readFileSync(configPath, 'utf8'));
}

function saveConfig(data) {
    fs.writeFileSync(configPath, JSON.stringify(data, null, 4));
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('freaky')
        .setDescription('manage the freak role system')
        .addSubcommand(sub =>
            sub.setName('setup')
                .setDescription('setup freak jail')
                .addChannelOption(opt =>
                    opt.setName('channel')
                        .setDescription('the only channel the freak role can see')
                        .addChannelTypes(ChannelType.GuildText)
                        .setRequired(true)
                )
        )
        .addSubcommand(sub =>
            sub.setName('jail')
                .setDescription('sentence user to freak jail')
                .addUserOption(opt =>
                    opt.setName('user')
                        .setDescription('user to sentence')
                        .setRequired(true)
                )
        )
        .addSubcommand(sub =>
            sub.setName('release')
                .setDescription('unjail a freaky user')
                .addUserOption(opt =>
                    opt.setName('user')
                        .setDescription('select a jailed user bud')
                        .setRequired(true)
                )
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const sub = interaction.options.getSubcommand();
        const guild = interaction.guild;
        const config = loadConfig();
        const guildId = guild.id;

        if (sub === 'setup') {
            const channel = interaction.options.getChannel('channel');
            await interaction.deferReply({ ephemeral: true });

            let freakRole;
            if (config[guildId]?.roleId) {
                freakRole = await guild.roles.fetch(config[guildId].roleId).catch(() => null);
            }

            if (!freakRole) {
                freakRole = await guild.roles.create({
                    name: 'freak',
                    permissions: [],
                    reason: 'freak quarantine role setup -clauz'
                });
            }

            const channels = await guild.channels.fetch();
            for (const [, ch] of channels) {
                if (!ch?.permissionOverwrites) continue;
                await ch.permissionOverwrites.edit(freakRole, {
                    ViewChannel: false,
                    SendMessages: false
                }).catch(() => {});
            }

            await channel.permissionOverwrites.edit(freakRole, {
                ViewChannel: true,
                SendMessages: true
            });

            config[guildId] = {
                roleId: freakRole.id,
                channelId: channel.id,
                jailedUsers: [],
                jailCounts: {}
            };
            saveConfig(config);

            await interaction.editReply(`✅ freak role updated and restricted to <#${channel.id}>`);
        }

        if (sub === 'jail') {
            const user = interaction.options.getUser('user');
            const member = await guild.members.fetch(user.id).catch(() => null);
            if (!member) return interaction.reply({ content: 'user not found bud', ephemeral: true });

            const guildConfig = config[guildId];
            if (!guildConfig?.roleId || !guildConfig?.channelId) {
                return interaction.reply({ content: 'freak role isnt set up yet! `/freaky setup`', ephemeral: true });
            }

            const freakRole = await guild.roles.fetch(guildConfig.roleId).catch(() => null);
            const jailChannel = await guild.channels.fetch(guildConfig.channelId).catch(() => null);

            if (!freakRole || !jailChannel) {
                return interaction.reply({ content: 'freak role or jail channel missing, use `/freaky setup` again lol', ephemeral: true });
            }

            await member.roles.add(freakRole).catch(() => {});
            if (!guildConfig.jailedUsers.includes(user.id)) {
                guildConfig.jailedUsers.push(user.id);
            }

            if (!guildConfig.jailCounts) guildConfig.jailCounts = {};
            const jailerId = interaction.user.id;
            if (!guildConfig.jailCounts[jailerId]) guildConfig.jailCounts[jailerId] = 0;
            guildConfig.jailCounts[jailerId]++;

            saveConfig(config);

            await interaction.reply(`🔒 <@${user.id}> has been sentenced to freaky jail lol`);
            await jailChannel.send(`🔒 new inmate has arrived ( <@${user.id}> )\n-# 🤔 sentenced by: <@${jailerId}>`);

            const ordinal = (n) => {
                const s = ['th', 'st', 'nd', 'rd'], v = n % 100;
                return n + (s[(v - 20) % 10] || s[v] || s[0]);
            };
            const count = guildConfig.jailCounts[jailerId];
            await interaction.user.send({
                content: `🔐 jailed that freak! \`${user.id}\`\n-# this is your **${ordinal(count)}** time you jailed someone because of being freaky..!`
            }).catch(() => {});
        }

        if (sub === 'release') {
            const user = interaction.options.getUser('user');
            const member = await guild.members.fetch(user.id).catch(() => null);
            if (!member) return interaction.reply({ content: 'user not found bud', ephemeral: true });

            const guildConfig = config[guildId];
            if (!guildConfig?.roleId || !guildConfig.jailedUsers?.includes(user.id)) {
                return interaction.reply({ content: 'ts user isnt freaky bud', ephemeral: true });
            }

            const freakRole = await guild.roles.fetch(guildConfig.roleId).catch(() => null);
            if (freakRole) {
                await member.roles.remove(freakRole).catch(() => {});
            }

            guildConfig.jailedUsers = guildConfig.jailedUsers.filter(id => id !== user.id);
            saveConfig(config);

            await interaction.reply(`🔓 <@${user.id}> has been released from the freaky jail`);
        }
    }
};
