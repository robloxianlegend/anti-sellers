const {
    SlashCommandBuilder,
    PermissionFlagsBits,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
} = require('discord.js');
const fetch = require('node-fetch');
require('dotenv').config();

const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const OWNER = 'robloxianlegend';
const REPO = 'anti-sellers';
const SELLERS_PATH = 'db.json';
const ADMINS_PATH = 'admins.json';
const BRANCH = 'main';

async function getFileShaAndContent(filePath) {
    const url = `https://api.github.com/repos/${OWNER}/${REPO}/contents/${filePath}?ref=${BRANCH}`;
    const res = await fetch(url, {
        headers: {
            Authorization: `token ${GITHUB_TOKEN}`,
            Accept: 'application/vnd.github.v3+json',
        },
    });
    if (!res.ok) throw new Error(`Failed to get file info: ${res.statusText}`);
    return await res.json();
}

async function updateFile(newContent, sha, message, filePath) {
    const url = `https://api.github.com/repos/${OWNER}/${REPO}/contents/${filePath}`;
    const body = {
        message,
        content: Buffer.from(JSON.stringify(newContent, null, 4)).toString('base64'),
        sha,
        branch: BRANCH,
    };

    const res = await fetch(url, {
        method: 'PUT',
        headers: {
            Authorization: `token ${GITHUB_TOKEN}`,
            Accept: 'application/vnd.github.v3+json',
        },
        body: JSON.stringify(body),
    });

    if (!res.ok) {
        const err = await res.text();
        throw new Error(`Failed to update file: ${err}`);
    }
    return await res.json();
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Ban related commands')
        .addSubcommand(subcommand =>
            subcommand
                .setName('add')
                .setDescription('Add a user ID to the sellers database')
                .addStringOption(option =>
                    option
                        .setName('id')
                        .setDescription('User ID to add')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('remove-seller')
                .setDescription('Remove a user ID from the sellers database')
                .addStringOption(option =>
                    option
                        .setName('id')
                        .setDescription('User ID to remove')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('sellers')
                .setDescription('Ban all sellers from the database')
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('add-admin')
                .setDescription('Add a user ID to the admins database (bot owner only)')
                .addStringOption(option =>
                    option
                        .setName('id')
                        .setDescription('User ID to add as admin')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('remove-admin')
                .setDescription('Remove a user ID from the admins database (bot owner only)')
                .addStringOption(option =>
                    option
                        .setName('id')
                        .setDescription('User ID to remove from admins')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('bulk')
                .setDescription('Ban multiple user IDs at once (admin only)')
                .addStringOption(option =>
                    option
                        .setName('ids')
                        .setDescription('Comma + space separated IDs to ban')
                        .setRequired(true)
                )
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        async function fetchAdmins() {
            const res = await fetch(`https://raw.githubusercontent.com/${OWNER}/${REPO}/${BRANCH}/${ADMINS_PATH}`);
            if (!res.ok) throw new Error('Failed to fetch admins list');
            return await res.json();
        }

        if (subcommand === 'add') {
            let admins;
            try {
                admins = await fetchAdmins();
            } catch {
                return interaction.reply({ content: '❌ Failed to fetch admins list.', ephemeral: true });
            }
            if (!admins.includes(interaction.user.id)) {
                return interaction.reply({ content: '❌ You are not authorized to use this command.', ephemeral: true });
            }

            const idToAdd = interaction.options.getString('id');
            if (!/^\d{17,19}$/.test(idToAdd)) {
                return interaction.reply({ content: '❌ Invalid user ID format.', ephemeral: true });
            }

            await interaction.deferReply({ ephemeral: true });

            try {
                const fileData = await getFileShaAndContent(SELLERS_PATH);
                const currentContent = Buffer.from(fileData.content, 'base64').toString('utf8');
                let sellersList = JSON.parse(currentContent);
                if (!Array.isArray(sellersList)) {
                    return interaction.editReply('❌ Sellers database format is invalid.');
                }
                if (sellersList.includes(idToAdd)) {
                    return interaction.editReply(`⚠️ ID \`${idToAdd}\` is already in the sellers database.`);
                }
                sellersList.push(idToAdd);
                await updateFile(sellersList, fileData.sha, `Add seller ID ${idToAdd}`, SELLERS_PATH);
                return interaction.editReply(`✅ Successfully added ID \`${idToAdd}\` to the sellers database.`);
            } catch (error) {
                return interaction.editReply(`❌ Failed to update sellers database: ${error.message}`);
            }

        } else if (subcommand === 'remove-seller') {
            let admins;
            try {
                admins = await fetchAdmins();
            } catch {
                return interaction.reply({ content: '❌ Failed to fetch admins list.', ephemeral: true });
            }
            if (!admins.includes(interaction.user.id)) {
                return interaction.reply({ content: '❌ You are not authorized to use this command.', ephemeral: true });
            }

            const idToRemove = interaction.options.getString('id');
            if (!/^\d{17,19}$/.test(idToRemove)) {
                return interaction.reply({ content: '❌ Invalid user ID format.', ephemeral: true });
            }

            await interaction.deferReply({ ephemeral: true });

            try {
                const fileData = await getFileShaAndContent(SELLERS_PATH);
                const currentContent = Buffer.from(fileData.content, 'base64').toString('utf8');
                let sellersList = JSON.parse(currentContent);
                if (!Array.isArray(sellersList)) {
                    return interaction.editReply('❌ Sellers database format is invalid.');
                }
                if (!sellersList.includes(idToRemove)) {
                    return interaction.editReply(`⚠️ ID \`${idToRemove}\` is not in the sellers database.`);
                }
                sellersList = sellersList.filter(id => id !== idToRemove);
                await updateFile(sellersList, fileData.sha, `Remove seller ID ${idToRemove}`, SELLERS_PATH);
                return interaction.editReply(`✅ Successfully removed ID \`${idToRemove}\` from the sellers database.`);
            } catch (error) {
                return interaction.editReply(`❌ Failed to update sellers database: ${error.message}`);
            }

        } else if (subcommand === 'sellers') {
            const owner = await interaction.guild.fetchOwner();
            if (interaction.user.id !== owner.id) {
                return interaction.reply({ content: '❌ Only the server owner can run this command.', ephemeral: true });
            }

            await interaction.deferReply({ ephemeral: true });

            try {
                const fileData = await getFileShaAndContent(SELLERS_PATH);
                const currentContent = Buffer.from(fileData.content, 'base64').toString('utf8');
                const sellersList = JSON.parse(currentContent);

                if (!Array.isArray(sellersList)) {
                    return interaction.editReply('❌ Sellers database format is invalid.');
                }
                if (sellersList.length === 0) {
                    return interaction.editReply('⚠️ Sellers database is empty.');
                }

                const bans = await interaction.guild.bans.fetch();
                const notBannedSellers = sellersList.filter(id => !bans.has(id));

                if (notBannedSellers.length === 0) {
                    return interaction.editReply('ℹ️ All sellers are already banned.');
                }

                const embed = new EmbedBuilder()
                    .setColor('#FFFFFF')
                    .setTitle(':face_vomiting: Ban Sellers')
                    .setDescription(`Are you sure you want to ban **${notBannedSellers.length}** sellers from your discord server?\n\n**What are sellers?**\nSellers are 16/18(+) freaks who sell inappropriate pictures of themselves\n\n**Why ban them?**\nSellers WILL spam your discord server with inappropriate stuff which may influence minors on your discord servers\n\n**How do they operate?**\n- They often use direct messages (DMs) to approach users privately with offers.\n- They may share links to external sites or platforms where the content is sold.\n- Sometimes, they use aggressive or manipulative tactics to convince users to pay or engage.\n- They may create multiple fake accounts to avoid bans and continue spamming.\n- They send inappropriate content\n\n**Risks sellers bring to your server**\n- Exposure of minors to explicit content, which is illegal and can cause serious harm.\n- **Violation of Discord’s Terms of Service, risking server suspension or deletion.**\n- Disruption of your community’s atmosphere, causing discomfort or distrust among members.\n- Possible scams or phishing attempts disguised as content sales.\n\nWe're actively finding sellers to add to the database to keep your discord server safe, if you'd like to keep your server safe from sellers, run this command every 3 days (to ban the new ones added to the database).\n\nBanning will never be automatic (to keep your trust!) Run the command whenever you'd like.\n\n**Here is a list of everyone on the database:** https://gatorkeys.xyz/db.json`)
                    .setImage('https://cdn.discordapp.com/attachments/1371492892228714518/1379003465136738314/image.png');

                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('confirmBanSellers')
                        .setLabel('Confirm Ban')
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId('cancelBanSellers')
                        .setLabel('Cancel')
                        .setStyle(ButtonStyle.Secondary)
                );

                await interaction.editReply({ embeds: [embed], components: [row] });
                const filter = i => ['confirmBanSellers', 'cancelBanSellers'].includes(i.customId) && i.user.id === interaction.user.id;
                const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

                collector.on('collect', async i => {
                    if (i.customId === 'confirmBanSellers') {
                        await i.deferReply({ ephemeral: true });

                        let bannedCount = 0;
                        let failedCount = 0;

                        for (const userId of notBannedSellers) {
                            try {
                                await interaction.guild.bans.create(userId, { reason: 'Banned by anti-sellers bot command.' });
                                bannedCount++;
                            } catch {
                                failedCount++;
                            }
                        }

                        await i.editReply(`✅ Banned ${bannedCount} sellers.${failedCount > 0 ? ` Failed to ban ${failedCount} users.` : ''}`);

                        await interaction.editReply({ components: [] });
                        collector.stop();
                    } else if (i.customId === 'cancelBanSellers') {
                        await i.update({ content: '❌ Ban canceled.', embeds: [], components: [], ephemeral: true });
                        collector.stop();
                    }
                });

                collector.on('end', async () => {
                    try {
                        await interaction.editReply({ components: [] });
                    } catch {}
                });

            } catch (error) {
                return interaction.editReply({ content: `❌ Failed to ban sellers: ${error.message}`, ephemeral: true });
            }

        } else if (subcommand === 'add-admin') {
            if (interaction.user.id !== '1268844772676730880') {
                return interaction.reply({ content: '❌ Only the bot owner can use this command.', ephemeral: true });
            }

            const idToAdd = interaction.options.getString('id');
            if (!/^\d{17,19}$/.test(idToAdd)) {
                return interaction.reply({ content: '❌ Invalid user ID format.', ephemeral: true });
            }

            await interaction.deferReply({ ephemeral: true });

            try {
                const fileData = await getFileShaAndContent(ADMINS_PATH);
                const currentContent = Buffer.from(fileData.content, 'base64').toString('utf8');
                let adminsList = JSON.parse(currentContent);
                if (!Array.isArray(adminsList)) {
                    return interaction.editReply('❌ Admins database format is invalid.');
                }
                if (adminsList.includes(idToAdd)) {
                    return interaction.editReply(`⚠️ ID \`${idToAdd}\` is already in the admins database.`);
                }
                adminsList.push(idToAdd);
                await updateFile(adminsList, fileData.sha, `Add admin ID ${idToAdd}`, ADMINS_PATH);
                return interaction.editReply(`✅ Successfully added ID \`${idToAdd}\` to the admins database.`);
            } catch (error) {
                return interaction.editReply(`❌ Failed to update admins database: ${error.message}`);
            }

        } else if (subcommand === 'remove-admin') {
            if (interaction.user.id !== '1268844772676730880') {
                return interaction.reply({ content: '❌ Only the bot owner can use this command.', ephemeral: true });
            }

            const idToRemove = interaction.options.getString('id');
            if (!/^\d{17,19}$/.test(idToRemove)) {
                return interaction.reply({ content: '❌ Invalid user ID format.', ephemeral: true });
            }

            await interaction.deferReply({ ephemeral: true });

            try {
                const fileData = await getFileShaAndContent(ADMINS_PATH);
                const currentContent = Buffer.from(fileData.content, 'base64').toString('utf8');
                let adminsList = JSON.parse(currentContent);
                if (!Array.isArray(adminsList)) {
                    return interaction.editReply('❌ Admins database format is invalid.');
                }
                if (!adminsList.includes(idToRemove)) {
                    return interaction.editReply(`⚠️ ID \`${idToRemove}\` is not in the admins database.`);
                }
                adminsList = adminsList.filter(id => id !== idToRemove);
                await updateFile(adminsList, fileData.sha, `Remove admin ID ${idToRemove}`, ADMINS_PATH);
                return interaction.editReply(`✅ Successfully removed ID \`${idToRemove}\` from the admins database.`);
            } catch (error) {
                return interaction.editReply(`❌ Failed to update admins database: ${error.message}`);
            }

        } else if (subcommand === 'bulk') {
            let admins;
            try {
                admins = await fetchAdmins();
            } catch {
                return interaction.reply({ content: '❌ Failed to fetch admins list.', ephemeral: true });
            }
            if (!admins.includes(interaction.user.id)) {
                return interaction.reply({ content: '❌ You are not authorized to use this command.', ephemeral: true });
            }

            const rawIds = interaction.options.getString('ids');
            const ids = rawIds.split(', ').filter(id => /^\d{17,19}$/.test(id));

            if (ids.length === 0) {
                return interaction.reply({ content: '❌ No valid user IDs provided. Use comma + space to separate.', ephemeral: true });
            }

            await interaction.deferReply({ ephemeral: true });

            let bannedCount = 0;
            let failedCount = 0;

            for (const userId of ids) {
                try {
                    await interaction.guild.bans.create(userId, { reason: 'Banned by /ban bulk command.' });
                    bannedCount++;
                } catch {
                    failedCount++;
                }
            }

            return interaction.editReply(`✅ Banned ${bannedCount} user(s).${failedCount > 0 ? ` ❌ Failed to ban ${failedCount} user(s).` : ''}`);
        }
    },
};
